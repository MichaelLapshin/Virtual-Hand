"""
Adapted from the MonoHand3D codebase for the MonocularRGB_3D_Handpose project (github release)

@author: Paschalis Panteleris (padeler@ics.forth.gr)
"""
